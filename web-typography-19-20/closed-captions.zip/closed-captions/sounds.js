// Hier kan je tijden toevoegen in secondes
// Op die mommenten komt er een class op de body.
sounds = [
	0,
	9,
	12.5,
	15,
	16.5,
	24,
	25.8,
	31,
	32,
	34,
	86
];
